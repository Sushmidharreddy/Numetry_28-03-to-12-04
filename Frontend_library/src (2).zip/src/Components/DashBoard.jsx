import React, { useState} from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import RegistrationService from '../Service/RegistrationService';
import AdminPage from './AdminPage';

function DashBoard() {
  const { state } = useLocation();
  const d = state.s;
  const r = d[d.length-1];
  const a=r.loginTime;
 
  console.log(d)
 
 
  // const r =d;
  // const a=r.loginTime;
  // console.log(a)

  

  const navigate = useNavigate();

  const logoutHandler = () => {
    logoutResponse();
  };
  const [hh,setHh] = useState();

  const logoutResponse=async()=>
  {
    try {
      const response=await RegistrationService.postDetailslogout(a); // Assuming r is defined somewhere
      
      console.log('Response Data:', response.data);

      setHh(response.data);
      console.log(hh)
      const s=response.data.logoutTime;
      d.logoutTime=s;
      const e=response.data.logoutDate
      d.logoutDate=e;
      console.log(d);
    
      if(response.data)
      {
        setHh(response.data); 
        console.log('Output after setting:',hh); // Log output state after setting
        navigate("/");
      }
    
    } catch (error) {
      console.error('Error occurred during logout:', error);
      // Handle error if necessary
    }
  }

  return (
    <div className='container mt-5'>
      <h4 className='d-inline-block me-5'>Welcome to Numetry Technologies Dashboard</h4>
      <button className='ms-5 btn btn-warning px-4 rounded-pill fw-bold' onClick={logoutHandler}>Logout</button>
      <table className='table table-striped table-bordered my-3'>
        <thead>
          <tr>
            <th>ID</th>
            <th>UserName</th>
            <th>Email</th>
            <th>LoginTime</th>
            <th>LoginDate</th>
            <th>LogoutTime</th>
            <th>LogoutDate</th>
          </tr>
        </thead>
        <tbody>
          {/* Map over output and render table rows */}
          {d.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.userName}</td>
              <td>{employee.email}</td>
              <td>{employee.loginTime}</td>
              <td>{employee.loginDate}</td>
              <td>{employee.logoutTime}</td>
              <td>{employee.logoutDate}</td>
            </tr>
          ))}
{/*             
            <tr >
              <td>{d.id}</td>
              <td>{d.userName}</td>
              <td>{d.loginTime}</td>
              <td>{d.loginDate}</td>
              <td>{d.logoutTime}</td>
              <td>{d.logoutDate}</td>
            </tr> */}
          

        </tbody>
      </table>
      <AdminPage/>
    </div>
  );
}

export default DashBoard;
