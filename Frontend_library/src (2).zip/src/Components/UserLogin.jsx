import React from 'react'
import { useLocation } from 'react-router-dom';

function UserLogin() {
    const {state}=useLocation();
    const uName=state.userName;
  return (
    <>
    <div className='container m-5'>
    <h3 >Welcome <span className="text-primary">{uName}</span> to Numetry Technogies..........</h3>
    </div>
   
    </>
  )
}

export default UserLogin;