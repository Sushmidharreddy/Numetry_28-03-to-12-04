import React, { useState } from 'react';
import RegistrationService from '../Service/RegistrationService';
import TextFiled from "@material-ui/core/TextField";

function AdminPage() {
    const [bookDetails, setBookDetails] = useState({
        bookName: "",
        bookAuthor: "",
        publisherName: "",
        publishingDate: "",
        totalCopies: "",
        issuedCopies: "",
        availableCopies: "",
        bookImage: null // Store the file object here
    });

    const onInputChange = (e) => {
        const { name, value } = e.target;
        setBookDetails({ ...bookDetails, [name]: value });
    };

    const onFileChange = (e) => {
        setBookDetails({ ...bookDetails, bookImage: e.target.files[0] }); // Update the file object
    };

    const onSubmit = (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('bookName', bookDetails.bookName);
        formData.append('bookAuthor', bookDetails.bookAuthor);
        formData.append('publisherName', bookDetails.publisherName);
        formData.append('publishingDate', bookDetails.publishingDate);
        formData.append('totalCopies', bookDetails.totalCopies);
        formData.append('issuedCopies', bookDetails.issuedCopies);
        formData.append('availableCopies', bookDetails.availableCopies);
        formData.append('bookImage', bookDetails.bookImage); // Append the file object

        RegistrationService.postBookDetails(formData).then((res) => {
            alert("Book added successfully");
        }).catch((error) => {
            console.error('Error submitting form:', error);
            alert('Failed to add book.');
        });
    };

    return (
        <div>
            <div className='text-center'>
                <form onSubmit={onSubmit}>
            
        <input type='text' name="bookName" value={bookDetails.bookName} onChange={onInputChange} className='m-2 p-2 rounded' placeholder='bookName' required/> <br/>
        <input type='text' name="bookAuthor" value={bookDetails.bookAuthor} onChange={onInputChange}  className='m-2 p-2 rounded' placeholder='bookAuthor'  required/>  <br/>
        <input type='text' name="publisherName" value={bookDetails.publisherName} onChange={onInputChange}  className='m-2 p-2 rounded' placeholder='publisherName' required/> <br/>
        <input type='date' name="publishingDate" value={bookDetails.publishingDate} onChange={onInputChange}  className='m-2 p-2 rounded' placeholder='publishingDate'  required/> <br/>
        <input type='text' name="totalCopies" value={bookDetails.totalCopies} onChange={onInputChange}  className='m-2 p-2 rounded'  placeholder='totalCopies' required/> <br/>
        <input type='text' name="issuedCopies" value={bookDetails.issuedCopies} onChange={onInputChange}  className='m-2 p-2 rounded' placeholder='issuedCopies'  required/> <br/>
        <input type='text' name="availableCopies" value={bookDetails.availableCopies} onChange={onInputChange}  className='m-2 p-2 rounded' placeholder='availableCopies'  required/> <br/>
        {/* <input type='file' name="bookImage" value={bookDetails.bookImage} onChange={onInputChange} className='m-2 p-2 rounded'/> <br/>  */}
        
        {/* <button className='btn btn-success px-5 mb-5'>Upload</button> */}

                    <input type='file' name="bookImage" onChange={onFileChange} className='m-2 p-2 rounded' /> <br />
                    {/* Other input fields */}
                    <button type="submit" className='btn btn-success px-5 mb-5'>Upload</button>
                </form>
            </div>
            <TextFiled variant="outlined" label="outlines" />
        </div>

        
    );
}

export default AdminPage;
