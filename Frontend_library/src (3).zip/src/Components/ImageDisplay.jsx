import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ImageDisplay = ({ imageId }) => {
  const [imageData, setImageData] = useState(null);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const response = await axios.get(`YOUR_BACKEND_ENDPOINT/${imageId}`, {
          responseType: 'arraybuffer',
        });
        const base64Image = Buffer.from(response.data, 'binary').toString('base64');
        setImageData(`data:image/jpeg;base64,${base64Image}`);
      } catch (error) {
        console.error('Error fetching image:', error);
      }
    };
    fetchImage();
  }, [imageId]);

  return (
    <div className="card">
      {imageData && (
        <img className="card-img-top" src={imageData} alt="Image" />
      )}
      <div className="card-body">
        <p className="card-text">Some description if needed</p>
      </div>
    </div>
  );
};

export default ImageDisplay;
