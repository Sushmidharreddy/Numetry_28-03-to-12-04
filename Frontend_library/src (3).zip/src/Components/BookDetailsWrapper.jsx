import React from 'react';

const BookDetailsWrapper = ({ book }) => {
  return (
    <div className="container">
      <h3>Book Details</h3>
      <div className="card w-100 h-100">
        <div className="card-body ">
          <h5 className="card-title">Book Name: {book.bookName}</h5>
          <p className="card-text">Author: {book.bookAuthor}</p>
          <p className="card-text">PublisherName: {book.publisherName}</p>
          <p className="card-text">Published Date: {book.publishingDate}</p>
          {/* Add more book details as needed */}
        </div>
      </div>
    </div>
  );
};

export default BookDetailsWrapper;
