import axios from 'axios';
const url="http://localhost:9292/api/v1/get";
const url1="http://localhost:9292/api/v1/post";
const url2="http://localhost:9292/api/v1/login";
const url3="http://localhost:9292/api/v1/logout";
const url4="http://localhost:9292/api/v1/role";
const url5="http://localhost:9292/api/v1/postBook";
const url6="http://localhost:9292/api/v1/getBook";



class RegistrationService
{
    getDetails()
    {
        return axios.get(url);
    }

    postDetails(values)
    {
        return axios.post(url1,values);
    }

    postDetailsLogin(credentials)
    {
        return axios.post(url2,credentials)
    }

    postDetailslogout(a)
    {
        return axios.post(url3+"/"+a,a);
    }

    getRole(userName) {
        return axios.post(url4 + "/" + userName, userName);
    }

    postBookDetails(formData)
    {
        return axios.post(url5,formData)
    }

    getBookDetails()
    {
        return axios.get(url6)
    }

  

   
}
export default new RegistrationService();